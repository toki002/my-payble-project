import React from 'react';
import Header from './components/Header';
import CoinList from './components/CoinList';
import Footer from './components/Footer';
import './App.css';

function App() {
  return (
    <div className="App">
      <Header />
      <main>
        <h2>Coin List</h2>
        <CoinList />
      </main>
      <Footer />
    </div>
  );
}

export default App;
